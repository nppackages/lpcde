## usethis namespace: start
#' @useDynLib lpcde, .registration = TRUE
#' @importFrom Rcpp evalCpp
## usethis namespace: end
NULL

